package com.springboot.microservices.banksystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.microservices.banksystem.Repository.UserRepository;
import com.springboot.microservices.banksystem.model.UserInfo;

@RestController
public class UserController {
	@RequestMapping("/hello")
	public String test() {
		return "Hello world";
	}
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private UserRepository userRepository;
	
	
	@PostMapping("/user/register")
	public UserInfo postUser(@RequestBody UserInfo userInfo) {
		String rawPassword = userInfo.getPassword();
		
		String encodedPassword = passwordEncoder.encode(rawPassword);
		
		userInfo.setPassword(encodedPassword);
		
		return userRepository.save(userInfo);
	}
}
