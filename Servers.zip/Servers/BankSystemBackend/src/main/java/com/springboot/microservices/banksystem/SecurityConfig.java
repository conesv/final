package com.springboot.microservices.banksystem;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.springboot.microservices.banksystem.service.MyUserDetailsService;

public class SecurityConfig extends WebSecurityConfigurerAdapter{
	UserDetailsService MyUserDetailsService;
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
		auth.inMemoryAuthentication()
		.withUser("harry")
		.password("{noop}potter")
		.roles("CUSTOMER")
		.and()
		.withUser("ronald")
		.password("{noop}wasley")
		.roles("CUSTOMER");
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception{
		http.httpBasic()
		.and()
		.authorizeRequests()
		.antMatchers(HttpMethod.POST, "/user/register").permitAll()
		.antMatchers(HttpMethod.GET, "/user/login").authenticated()
		.and()
		.csrf().disable();
	}
	
	@Bean
	public PasswordEncoder getPaswordEncoder(){
		PasswordEncoder passEncoder = new BCryptPasswordEncoder();
		return passEncoder;
	}
	public DaoAuthenticationProvider myAuthManager() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		
		authProvider.setUserDetailsService(MyUserDetailsService);
		authProvider.setPasswordEncoder(getPaswordEncoder());
		return authProvider;
	}
	
}
