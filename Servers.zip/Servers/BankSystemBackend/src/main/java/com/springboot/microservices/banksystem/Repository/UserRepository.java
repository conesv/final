package com.springboot.microservices.banksystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.springboot.microservices.banksystem.model.UserInfo;

public interface UserRepository extends JpaRepository<UserInfo, Long> {
	@Query("Select u from UserInfo u where u.username=?1 and active=?2")
	UserInfo fetchByUserName(String username, boolean b);

}
