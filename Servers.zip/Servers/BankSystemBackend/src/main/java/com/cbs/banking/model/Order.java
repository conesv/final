package com.cbs.banking.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Order {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Long id;

@Column(length=1000)
private String orderDetails;

private String expcetedDateOfFulfillment;

private double amount;

@OneToOne
private Project Project;

@OneToOne
private Payment payment;

private String status;

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getOrderDetails() {
	return orderDetails;
}

public void setOrderDetails(String orderDetails) {
	this.orderDetails = orderDetails;
}

public String getExpcetedDateOfFulfillment() {
	return expcetedDateOfFulfillment;
}

public void setExpcetedDateOfFulfillment(String expcetedDateOfFulfillment) {
	this.expcetedDateOfFulfillment = expcetedDateOfFulfillment;
}

public double getAmount() {
	return amount;
}

public void setAmount(double amount) {
	this.amount = amount;
}

public Project getProject() {
	return Project;
}

public void setProject(Project project) {
	Project = project;
}

public Payment getPayment() {
	return payment;
}

public void setPayment(Payment payment) {
	this.payment = payment;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}


}
