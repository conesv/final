package com.cbs.banking.model;

public class Project {

}
