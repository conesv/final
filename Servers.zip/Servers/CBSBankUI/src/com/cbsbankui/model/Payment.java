package com.cbsbankui.model;


public class Payment {

}
